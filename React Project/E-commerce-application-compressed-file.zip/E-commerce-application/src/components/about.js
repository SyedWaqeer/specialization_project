import React from "react";

import 'bootstrap/dist/css/bootstrap.min.css';
import './about.css'


const About = () => {

    return (
            <div>
            <div className="container py-5 my-5">
            <div className="row">
            
            <div className="col-md-6 d-flex justify-content-center">
            <img src="https://s3u.tmimgcdn.com/800x0/u2303654/0cbada6a68673680eed6bebbeb98006b.jpg" alt="About Us" height="500px" width="550px" />
            </div>
            <div className="col-md-6">
            <h1 className="abt">About Us</h1><br></br><br></br>
            <p className="lead mb-4">
            From the rich and diverse culture of India, we bring to you the feel of grandeur and celebration.
            Our handmade products are a tribute to our culture. Explore the handcrafted and highly functional 
            range of bags for all your needs. Our products are 100% Vegan and Proudly Indian.
            ﻿We want to take the rich Indian heritage in a modern avatar to everyone worldwide. 
            We insist on being 100% Vegan and focus on making our products useful. Style with substance is key.
            We want our customers to make Zouk a part of their most cherished experiences, be it that promotion 
            day in office or that fantasy vacation to Maldives or as a special gift to a loved one. 
            </p>
            </div>
            </div>
            </div>
            
            
            
            
            
            </div>
    );
}

export default About;