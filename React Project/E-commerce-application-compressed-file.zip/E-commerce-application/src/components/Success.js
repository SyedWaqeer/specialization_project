import React from 'react';
import "./Success.css"
import { Link } from 'react-router-dom';

const Success = () => {

    return (
      <div className='center'>
        <br></br>
      
        <div className='order'>
    
        <div className='card'>
        <div className='card1'>
          <i className='i'>✓</i>
        </div>
          <h1 className='h1'>Success</h1> 
          <p className='p'>We received your purchase request<br/> Transaction Id : #45678932</p>
        </div>
        </div>
        <div className='buttoncenter'>
        <div class="btn btn-warning"><Link to="/">Continue Shopping</Link> </div></div>
        <br></br>
        <br></br>
        <br></br>
        <br></br>
        </div>

       
        )
    }

export default Success;
    