import React, { Component } from 'react';
import { Link } from 'react-router-dom';
import "./Logout.css";
 export default class Logout extends Component{
     constructor(props){
         super(props)

     }
     render(){
         return(
             <div className='hi'>
                  <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <h1>You have been Logged out!!!</h1>
                 {/* <button className='logout'><Link to="/login">Login Again</Link></button> */}

                 <div class="btn btn-danger"><Link to="/login">Login again</Link> </div>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                 <br/>
                
                 


             </div>
         )
     }
 }