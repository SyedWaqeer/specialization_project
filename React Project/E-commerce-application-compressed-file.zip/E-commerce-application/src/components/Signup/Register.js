// import React from 'react';
// import { Link } from "react-router-dom"
// import useForm from "./useForm";
// import validate from "./Validation";
// import FormSuccess from "./FormSuccess";
// import axios from 'axios'

// export default function Register() {

//     const { handleInput, handleSubmit, values, errors, isSubmitting } = useForm(validate);

//     return (
//         <section>
//             { (Object.keys(errors).length === 0 && isSubmitting) ? (<FormSuccess name={values.username} />) :
//                 (<div className="form-container">
//                     <h2>Login/Register</h2>
//                     <form onSubmit={handleSubmit} autoComplete="off" noValidate>
//                         <div className="form-input">
//                             <label>Name</label>
//                             <input name="username" type="text" onChange={handleInput} value={values.username} />
//                             {errors.username && <small className="form-error">{errors.username}</small>}
//                         </div>

//                         <div className="form-input">
//                             <label>Email</label>
//                             <input name="email" type="text" onChange={handleInput} value={values.email} />
//                             {errors.email && <small className="form-error">{errors.email}</small>}
//                         </div>
//                         <div className="form-input">
//                             <label>Mobile No.</label>
//                             <input name="mobileno" type="number" onChange={handleInput} value={values.mobileno} />
//                             {errors.mobileno && <small className="form-error">{errors.mobileno}</small>}
//                         </div>

//                         <div className="form-input">
//                             <label>Password <span className="tooltip"> &#9432;
//             	                <span className="tooltip-text">Password must have atleast: <br /><br />
//                                 &#8226; 1 digit (0-9)<br />
//                                 &#8226; 1 uppercase &amp; 1 lowercase alphabet<br />
//                                 &#8226; 1 special character (!#$@^%&amp;?)<br />
//                                 &#8226; 8 characters &amp; less than 20 characters</span>
//                                 </span>
//                             </label>
//                             <input name="password" type="password" onChange={handleInput} value={values.password} />
//                             {errors.password && <small className="form-error">{errors.password}</small>}
//                         </div>

//                         <button type="submit" className="form-btn">Submit<Link to='/' >Submit</Link></button><br />
//                         <small>
//                             Already have an account? <Link to='/login'>Login </Link>
//                         </small>
//                     </form>
//                 </div>)}
//         </section>
//     )
// }



import React, { Component } from 'react'
import axios from 'axios'
import "./Register.css"
import { Link } from "react-router-dom"


class Register extends Component{
    constructor(props){
        super(props);
        this.state={
            id:'',
            fullname:'',
            email:'',
            password:'',
            mobile:'',
            city:''
        }
    }
    handleChange=(event)=>
    {

        this.setState({[event.target.name] : event.target.value})
    }

    handleSubmit =(event)=>
    {

        event.preventDefault()
        
        axios.post('http://localhost:8080/saveCustomer',this.state)
        .then(res =>{
            console.log(res.data)
        })
        .catch(error=>{
            console.log(error)
        })
    }

    
    render(){
        const{fullname,email,password,mobile,city}=this.state
        return(      
<div className='reg'>
<main class="form-signin">
<form onSubmit={this.handleSubmit}> 
{/* <img class="mb-4" src="/docs/5.1/assets/brand/bootstrap-logo.svg" alt="" width="72" height="57"/> */}
{/* <h1 class="h3 mb-3 fw-normal"> Register</h1> */}
<br/>

<h1 className='regi'>Register</h1>

<div class="form-floating">
<input type="fullname" class="form-control" id="fullname" name="fullname" value={fullname} onChange={this.handleChange}placeholder="name"/>
<label htmlFor="fullname">Enter FullName</label>
</div>
<br></br>

<div class="form-floating">
<input type="email" class="form-control" id="email" name="email" value={email} onChange={this.handleChange}placeholder="name@example.com"/>
<label htmlFor="floatingInput">Email address</label>
</div>
<br></br>



<div class="form-floating">
<input type="password" class="form-control" id="password" name="password" value={password} onChange={this.handleChange}placeholder="Password"/>
<label htmlFor="floatingPassword">Password</label>
</div>
<br></br>



<div class="form-floating">
<input type="mobile" class="form-control" id="mobile" name="mobile" value={mobile} onChange={this.handleChange} placeholder="enter 10-digit mob num"/>
<label htmlFor="mobile">Mobile Number</label>
</div>
<br></br>
<div class="form-floating">
<input type="city" class="form-control" id="city" name="city" value={city} onChange={this.handleChange} placeholder="city"/>
<label htmlFor="floatinginput">City</label>
</div>
<br></br>

<button class="btn btn-primary payment" type="submit" value="register">Register</button>

{/*  */}<br></br>
<small>
                           Already have an account? 
                           {/* <button><Link to='/login'>Login </Link></button> */}
                           <div class="btn btn-danger"><Link to="/login">Login</Link> </div>
</small>

</form>
</main>
</div>
            
        )
    }
}
export default Register;